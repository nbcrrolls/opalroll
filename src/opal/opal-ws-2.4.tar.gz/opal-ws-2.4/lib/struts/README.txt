This lib are here baecause of the opalGUI

antlr-2.7.2.jar
commons-beanutils-1.7.0.jar
commons-chain-1.1.jar
commons-digester-1.8.jar
commons-fileupload-1.2.jar
commons-io-1.1.jar
commons-validator-1.3.1.jar
jstl.jar
oro-2.0.8.jar
standard.jar
struts-core-1.3.8.jar
struts-extras-1.3.8.jar
struts-taglib-1.3.8.jar

clem
