package edu.sdsc.nbcr.opal.manager.condorAPI;

/**
 * Interface for event handlers.
 */
public interface Handler {
  public void handle(Event e);
}
