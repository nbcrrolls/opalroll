package edu.sdsc.nbcr.opal.manager.condorAPI;


/**
 * this class meant to represents a node in parallel jobs.
 * For now, there is no contents here.
 */ 
public class Node {

}
