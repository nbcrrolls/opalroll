package edu.sdsc.nbcr.opal.manager.condorAPI;

public class CondorException extends Exception {
  public CondorException (String str){
	super(str);
  }
}
