dom-min.js  
yahoo-min.js

Yahoo YUI 
BSD License
version: 2.3.1
-----------------------------
ext-all.js  
ext-base.js

ext-JS
GPS 3 licence
3.0.0 
-----------------------------
clem

jquery.js - jQuery JavaScript Library v1.3.2 http://jquery.com/
jquery.corner.js - jquery corner plugin version 1.7
RowExpander.js - from Ext JS Library 3.1.1
services-panel.js - code moved from dashboard-jsp/serviceList.jsp
